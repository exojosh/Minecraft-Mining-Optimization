/* Code by Josh Limon
12/15/2020
Data counter: counts how many numbers are in a data[i].txt where numbers you want to count
are seperated by commas or a newline (or both).
*/

using namespace std;

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>


int main()
{
	int blocks[130] = { 0 }; 
	ifstream infile;
	string str, datum, line;
	int i = 0, total = 0, index;
;	for (; i < 10; i++)
	{
		str = "C:\\Users\\jjlem\\Desktop\\MC Data analysis\\data" + to_string(i) + ".txt";
	//str = "C:\\Users\\jjlem\\Desktop\\MC Data analysis\\data.txt"; (Test data file)
		infile.open(str,ios::in);
		if (!infile.is_open())
		{
			exit(EXIT_FAILURE);
		}
		while (getline(infile, line))
		{
			std::stringstream ss(line);
			while (getline(ss, datum, ','))
			{
				//cout << datum << ", " << total << '\n'; (Outputs allldata as it's input, totally inefficient)
				index = stoi(datum);
				blocks[index]++;
				total++;
			}
		}
		infile.close();
	}
	std::cout << "Block ID, Quantity" << endl;
	for (int j = 0; j < 130; j++)
		std::cout << j << ", " << blocks[j] << '\n';
std:; cout << "\n\n" << "Total: " << total;

	return 0;
}